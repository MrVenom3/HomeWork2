public class Instructor extends User{
	
	private int diplomeNumber;
	private String profession;
	
	public int getDiplomeNumber() {
		return diplomeNumber;
	}
	public void setDiplomeNumber(int diplomeNumber) {
		this.diplomeNumber = diplomeNumber;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
}