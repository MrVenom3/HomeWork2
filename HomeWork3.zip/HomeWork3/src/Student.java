public class Student extends User{
	
	private String areaInterest;

	public String getAreaInterest() {
		return areaInterest;
	}

	public void setAreaInterest(String areaInterest) {
		this.areaInterest = areaInterest;
	}
}